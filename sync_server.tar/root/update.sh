apt-get update && apt-get update && apt-get upgrade && apt-get dist-upgrade && apt-get autoclean && apt-get autoremove
